from django.shortcuts import render
from movie.models import Post
from django.contrib.auth import authenticate

# Create your views here.
def home(request):
    allPosts= Post.objects.all()
    context={'allPosts': allPosts}
    return render(request,'home.html',context)

def homeh(request):
    query = request.GET['query']
    allPosts= Post.objects.filter(title__icontains=query)
    params={'allPosts': allPosts}
    return render(request, 'search.html', params)
def main(request):
    if request.method == "POST":
        about2= request.POST.get('about2')
        number = request.POST.get('number1')
        name = request.POST.get('name')
        filesize = request.POST.get('filesize')
        photosrc = request.POST.get('photosrc')
        title = request.POST.get('title')
        link = request.POST.get('link')
        about =request.POST.get('about')
        post = Post(title=title, link=name, photosrc=photosrc)
        post.save()
        fo = open("static/"+name+".html", "w")
        fo.write('''
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
      <style>
    form{
    min-width: 100%;
    text-align: center;
}
#search{
    min-width: 90%;
    border-radius: 25px;
}
.define{
    max-width: 100%;
    text-align: center;
}
.input{
   min-width: 90%;
   margin: 5px;
}
form{
    border:1px solid;
}
.bor{
    border: 1px solid black;
}
.makein{
    width: 90px;
    height: 30px;
    border-radius: 50px;
    background-color: blue;
    color: white;
    position: relative;
    left: 70px;
}
.container{
    min-width: 100%;
    text-align: center;
}
.ex{
    max-width: 100%;
    text-align: center;
}
#title{
    text-decoration: underline;
    font-size: 30px;
}
img{
    height: 200px;
    width: 200px;
}
button{
    border-radius: 50%;
    width: 100px;
    background-color: blue;
    color: white;
    text-align: center;
    height: 40px;
}

    </style>
    <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
    <h1>freemovies.com</h1><br>
    <form action="/search" method="GET">
        <input type="search" name="query" id="search" placeholder="search"><br>
    </form><hr><div class="ex">
    <h3 id="title">'''+title+'''</h3><br>
    <img src="/static/images/'''+photosrc+'''.jpg" alt=""></div>
     <div class="define"><span>file-size|'''+filesize+'''</span></div>
    <p>story of movie is-<br>'''+about+'''</p><br><div class="container">
    <a href="'''+link+'''" id="div"><button>click here to download</button></a></div>
    <p>
'''+about2+'''
    </p><br>
</body>
</html>'''
        )
        fo.close
    if request.method == "GET":
        names = request.GET['names']
        passw = request.GET['passw']
        user = authenticate(username=names, password=passw)
        if user is not None:
            return render(request, 'super.html')  
        else:
            pass
    return render(request,'new.html')

def new(request):
    return render(request,'new.html')
