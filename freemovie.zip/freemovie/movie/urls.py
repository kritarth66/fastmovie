from django.contrib import admin
from django.urls import path
from movie import views

urlpatterns = [
    path('',views.home,name="home"),
    path('search',views.homeh,name="search"),
    path('superuser',views.main,name="main"),
    path('add',views.new,name ="add"),
]
